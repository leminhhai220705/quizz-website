import React from 'react';

const NotFoundPage = () => {
  return (
    <div className="intro--header">
      <div className="inner--header">
        <h1>404 :(</h1>
        <span>Deze pagina is niet gevonden.</span>
      </div>
    </div>
  );
}

export default NotFoundPage;
